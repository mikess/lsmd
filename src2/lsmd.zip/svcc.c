#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
	FILE *fd;

	if((fd = fopen("test.txt", "rt")) == NULL)
		return 66;

	char *buf;
	buf = (char*) malloc( sizeof(char)) ;
	int ret = 0;
	while(fgets(*buf, sizeof(buf), fd)){
		char *var;
		char *val;
		sscanf(buf, "%[^\n=]=%[^\n]", &var, &val);
		printf("Var: %s || Val: %s\n", &var, &val);
	}
}
