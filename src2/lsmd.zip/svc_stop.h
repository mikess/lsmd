
int svc_stop_service(svc_s serviceid);
int svc_stop_all(void);
